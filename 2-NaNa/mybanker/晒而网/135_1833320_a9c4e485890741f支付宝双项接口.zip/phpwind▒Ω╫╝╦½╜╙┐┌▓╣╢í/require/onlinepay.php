<?php
!function_exists('readover') && exit('Forbidden');

/**
 *
 * phpwind ����֧��ͳһ���
 * author:chenjm@phpwind.net / sky_hold@163.com
 *
 */
Class OnlinePay {

	var $charset;
	var $seller_email;
	var $baseurl;

	var $alipay_url	= 'https://www.alipay.com/cooperate/gateway.do?';
	var $alipay_key;
	var $alipay_partnerID;

	var $pwpay_url	= 'http://pay.phpwind.net/pay/create_payurl.php?';
	var $pwpay_key;
	var $pwpay_partnerID;

	function OnlinePay($email) {
		$this->seller_email = $email;
		$this->charset = $GLOBALS['db_charset'];
		$this->baseurl = $GLOBALS['db_bbsurl'];

		$this->alipay_key = $GLOBALS['ol_alipaykey'];
		$this->alipay_partnerID = $GLOBALS['ol_alipaypartnerID'];

		$this->pwpay_key = $GLOBALS['db_siteid'];
		$this->pwpay_partnerID = $GLOBALS['db_sitehash'];
	}

	//$extra�����������,������Ч
	function alipayurl($order_no, $fee, $paytype,$extra='') {

		$param = array(
			'_input_charset'	=> $this->charset,
			'service'			=> 'create_direct_pay_by_user',
			'notify_url'		=> $this->baseurl.'/alipay.php',
			'return_url'		=> $this->baseurl.'/alipay.php',
			'payment_type'		=> '1',
			'subject'			=> getLangInfo('olpay', "olpay_{$paytype}_title", array('order_no' => $order_no)),
			'body'				=> getLangInfo('olpay', "olpay_{$paytype}_content"),
			'out_trade_no'		=> $order_no,
			'total_fee'			=> $fee,
			'extra_common_param' => $this->formatExtra($extra),
			'seller_email'		=> $this->seller_email
		);
		
		/*********************************\
		*                                 *
		* ��ʱ���˽ӿڵ���׼˫�ӿڵ�ת��  *
		*                                 *
		\************ start **************/

		$this->alipay_url = 'https://mapi.alipay.com/gateway.do?';
		$param["service"] = 'trade_create_by_buyer';
		$param["price"] = $fee;
		$param["quantity"] = '1';
		$param["logistics_fee"] = '0.00';
		$param["logistics_type"] = 'EXPRESS';
		$param["logistics_payment"] = 'SELLER_PAY';
		
		/*********************************\
		*                                 *
		* ��ʱ���˽ӿڵ���׼˫�ӿڵ�ת��  *
		*                                 *
		\************* end ***************/

		if ($this->alipay_key && $this->alipay_partnerID) {
			$url = $this->urlCompound($this->alipay_url, $this->alipay_partnerID, $this->alipay_key, $param);
		} else {
			Showmsg('֧��ʧ�ܣ���վ����δ��д֧�����̻���Ϣ(partnerID��key)�����¼��̨->����֧����д!');
			$url = $this->urlCompound($this->pwpay_url, $this->pwpay_partnerID, $this->pwpay_key, $param);
		}
		return $url;
	}

	function formatExtra($extra) {
		$extraLen = strlen($extra);
		if ($extraLen > 100) $extra = '';
		if ($extra == '') return '';
		$param = array();
		for($i = 0,$cnt = strlen($extra);$i<$cnt;$i++){
			$param[] = ord($extra{$i});
		} 
		return implode('.',$param); 
	}
	function alipay2url($param) {
		$param['service']			= 'trade_create_by_buyer';
		$param['_input_charset']	= $this->charset;
		$param['seller_email']		= $this->seller_email;

		if (0 && $this->alipay_key && $this->alipay_partnerID) {
			$url = $this->urlCompound($this->alipay_url, $this->alipay_partnerID, $this->alipay_key, $param);
		} else {
			$url = $this->urlCompound($this->pwpay_url, $this->pwpay_partnerID, $this->pwpay_key, $param);
		}
		return $url;
	}

	function urlCompound($url, $partnerID, $partnerKey, $param) {
		$param['partner'] = $partnerID;
		ksort($param);
		reset($param);
		$arg = '';
		foreach ($param as $key => $value) {
			if ($value) {
				$url .= "$key=".urlencode($value)."&";
				$arg .= "$key=$value&";
			}
		}
		$url .= 'sign='.md5(substr($arg,0,-1).$partnerKey).'&sign_type=MD5';
		return $url;
	}
}
?>